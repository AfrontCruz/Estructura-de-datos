//Esta es nuestra librer�a donde se declaran las funciones, la estructura, se define el valor de nuestra pila
//y se define _PILAESTATICA_.
#ifndef _PILAESTATICA_
#define _PILAESTATICA_

#define MAX 50

typedef struct pilae pilae;

struct pilae{
	int vector[MAX];
	int tope;
};

pilae *CreaPila(void);
pilae *push(pilae *, int elem);
pilae *BorrarPila(pilae *c);
pilae *pop(pilae *pila);
void top(pilae *pila);
void vacio(pilae *pila);
void lleno(pilae *pila);

#endif
